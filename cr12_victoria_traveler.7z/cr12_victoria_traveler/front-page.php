<?php get_header(); ?>

<div id="frontbody"></div>

<?php get_footer(); ?>